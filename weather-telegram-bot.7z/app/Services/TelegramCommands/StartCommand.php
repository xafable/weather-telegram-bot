<?php

namespace App\Services\TelegramCommands;

use App\Models\User;
use App\Services\Telegram;
use Illuminate\Support\Facades\DB;
use Telegram\Bot\Commands\Command;

class StartCommand extends Command
{
    protected string $name = 'start';
    protected string $description = 'Start Command to get you started';

    public function __construct(Telegram $telegram)
    {
        $this->telegram = $telegram->getApiInstance();
    }

    public function handle()
    {

        $update = $this->getUpdate();


        $userExist = User::query()->where('telegram_id','=',$update->message->from->id)->exists();



        if($userExist)
            $this->replyWithMessage([
                'text' => 'Натисніть кнопку Menu щоб обрати необхідну функцюю.',
            ]);
        else {
            User::query()
                ->create([
                    'telegram_id'=>$update->message->from->id,
                ]);

            $this->triggerCommand('select_city');
        }


    }

}
