<?php

use App\Http\Controllers\TelegramController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use Telegram\Bot\Laravel\Facades\Telegram;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/


Route::post('/', [TelegramController::class, 'handle']);


Route::post('/token/webhook', function () {
    $update = Telegram::commandsHandler(true);

    return 'ok';
});


Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});
