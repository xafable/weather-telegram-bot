
    <b><?php echo e(Illuminate\Support\Carbon::createFromFormat('Y-m-d', $weather->dayDate)->locale('uk')->dayName); ?></b>
    Температура: <b><?php echo e($weather->dayTemp); ?></b>
    Вітер: <b><?php echo e($weather->dayTemp); ?></b>
        <?php $__currentLoopData = $weather->hourly; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $w): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    Час:<b><?php echo e(\Illuminate\Support\Str::substr($w['time'],10)); ?></b>
    Температура: <b><?php echo e($w['temp']); ?></b>
    Вітер: <b><?php echo e($w['windSpeed']); ?></b>
    Опис: <b><?php echo e($w['weatherDescription']); ?></b>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>







<?php /**PATH C:\OSPanel\domains\weather-telegram-bot\resources\views/weatherMessage.blade.php ENDPATH**/ ?>